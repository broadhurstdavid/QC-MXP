All the examples in this folder are deidentified and not associated with any biological outcome. Sample data has been obfuscated using a random number generator.
All meta data beyond SampleType, Order, & Batch, have been artificially generated. 
The data sets are of no value beyond demonstrating the use of this application. Please do not use them in any publications.
